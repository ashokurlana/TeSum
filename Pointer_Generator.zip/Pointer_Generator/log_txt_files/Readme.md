It's a log file directory.
